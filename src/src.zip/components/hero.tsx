export default function Hero() {
    return (
      <section className="flex min-h-[calc(100vh-3.5rem)] items-center">
        <div className="container">
          <h1 className="text-4xl font-bold tracking-tight sm:text-6xl md:text-7xl">
            I&apos;m <span className="text-muted-foreground">Andrew Qiao.</span> I build what the world needs{" "}
            <span className="text-muted-foreground">tomorrow</span>, today.
          </h1>
        </div>
      </section>
    )
  }
  
  