import Hero from "@/components/hero"
import Navbar from "@/components/navbar"

export default function Page() {
  return (
    <main className="flex min-h-screen flex-col bg-background">
      <Navbar />
      <Hero />
    </main>
  )
}

